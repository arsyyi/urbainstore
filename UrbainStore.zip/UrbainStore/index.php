<?php

header('Location:Pages/Homepage.php');

?>